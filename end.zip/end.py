import pandas as pd
import numpy as np
import random
unit_step = lambda x: 0 if x < 0 else 1

counter = 0
weights = []
Accuracy = 0
Precision = 0
recall = 0


def train():
    Train_data = pd.read_excel(r'C:\Users\HAFSA RIAZ\Desktop\Book2.xlsx', header=None)
    alpha = 0.3
    bias = -1
    sum = 0
    i = 0

    Initial_weights = [random.uniform(-0.6, 0.6) for i in range(0, len(Train_data.columns))]
    for epoch in range(5):
        counter = 0
        while counter < Train_data.shape[0]:
            rows = np.append(Train_data.iloc[counter, 0:Train_data.shape[1] - 1].values, bias)
            for data in rows:
                sum = sum + (data * Initial_weights[i])
                i = i + 1
            Expected = unit_step(sum)

            Actual = Train_data[Train_data.shape[1] - 1][counter]
            error = Actual - Expected
            i = 0
            for data in rows:
                Initial_weights[i] = Initial_weights[i] + alpha * error * data
                i = i + 1
            i = 0
            sum = 0
            counter = counter + 1
            write_Data(epoch, rows, Initial_weights, Expected, Actual, error)

    file = open("Weights.txt", "w")
    for weight in Initial_weights:
        file.write(str(weight) + "\n")
    file.close()
    print_Data(Initial_weights,Train_data)

def test():
    global weights
    count = 0

    Test_data = pd.read_excel(r'C:\Users\HAFSA RIAZ\Desktop\Book1.xlsx', header=None)
    for appending in range(len(Test_data.columns)):
        weights.append(0)

    file = open("Weights.txt", "r")
    for line in file:
        weights[count] = float(line)
        count = count + 1
    print_Data(weights,Test_data)




def predict(weights, X):
    predictions = []
    counter = 0
    bias=-1
    while counter < X.shape[0]:
        new_one = np.append(X.iloc[counter, 0:X.shape[1] - 1].values, bias)
        i = 0
        sum = 0
        for each_data in new_one:
            sum = sum + (each_data * weights[i])
            i = i + 1

        predicted_value = unit_step(sum)
        predictions.append(predicted_value)
        counter = counter + 1
    return predictions






def print_Data( weights,final_data):
    global Accuracy
    global Precision
    global recall

    predictions = predict(weights, final_data)
    cm = [[0, 0], [0, 0]]
    outputs=final_data.iloc[:, -1].values
    for i in range(0, len(predictions)):
        cm[int(predictions[i])][int(outputs[i])] += 1
    Final_Matrix=cm
    Accuracy = (Final_Matrix[0][0] + Final_Matrix[1][1]) / (Final_Matrix[0][0] + Final_Matrix[0][1] + Final_Matrix[1][0] + Final_Matrix[1][1]) * 100
    print("Accuracy=", Accuracy, "%")

    #Precision = (Final_Matrix[0][0]) / (Final_Matrix[0][0] + Final_Matrix[0][1]) * 100
    #print("Precision=", Precision, "%")







def write_Data(epoch, rows,Initial_weights, Expected, Actual, error):

    file = open("Trained_Data.txt", "a")
    file.write(str(epoch) + "     ")
    for data in rows:
        file.write(str(data) + "  ")
    file.write("       ")

    for each_weight in Initial_weights:
        #print(each_weight)
        file.write(str(each_weight) + "  ")
    file.write("       " + str(Actual))
    file.write("       " + str(Expected))
    file.write("       " + str(error))
    file.write("\n")
    file.close()



def type(check):
    if (check == "test"):
        test()
    else:
        train()
arg = "train"
if __name__=="__main__":
    type(arg)








